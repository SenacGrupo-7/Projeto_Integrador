package com.example;

public class Professor extends Pessoa {

	private char disciplina;

	private double salario;

	private Pessoa pessoa;

    public Professor(String nome, String endereco, String telefone, String disciplina1, double salario1) {
        super(nome, endereco, telefone);
    }

	public void getDisciplina() {

	}

	public void getSlario() {

	}

}
